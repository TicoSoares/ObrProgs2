from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Button, Color, Direction, Port, Axis
from pybricks.robotics import DriveBase
from pybricks.tools import wait

from ExtraTools import *

sensorD = ColorSensor(Port.A)
sensorE = ColorSensor(Port.C)
ultraF = UltrasonicSensor(Port.F)
ultraT = UltrasonicSensor(Port.E)
motorD = Motor(Port.B, Direction.COUNTERCLOCKWISE)
motorE = Motor(Port.D)
drive = DriveBase(motorE, motorD, 30.9, 137.5)
drive.settings()
default_settings = drive.settings()
drive.settings(539.9999, 5393.99, 100)
fast_settings = drive.settings()
drive.settings(539.9999, 300, 100)
reta_settings = drive.settings()
drive.use_gyro(True)

colors = {
    "green": Color.GREEN,
    "prata": Color.VIOLET,
    "red": Color.RED,
    "preto": Color.BLACK,
    "branco": Color.WHITE
}
colors_copy = colors.copy()
colors_array = ["green", "prata", "red", "branco"]

pid_erro = 0
integral = 0
last_error = 0

vermelho = False

erro_vel_factor = 0.3
forcaBase = 355
vel_virada = 400
_KP = 9.2
_KI = 0.0
_KD = 7
tamanho_garra = 110
raio_obs = 37.0
margem_obs = 53.0
raio_robo = 84.0
total_raio = raio_obs + margem_obs + raio_robo

contador_retas_temp = 1

timer_noventa = StopWatch()
timer_noventa.pause()

historico_angulos = []  # Histórico de ângulos
tamanho_janela = 10  # Janela de leituras (ajustável)
angulo_medio = 0  # Ângulo médio atualizado
intervalo_leitura = StopWatch()  # Cronômetro para controlar leituras

def atualizar_angulo_medio():
    global angulo_medio, historico_angulos

    if intervalo_leitura.time() >= 20:  # Verificação a cada 20ms
        intervalo_leitura.reset()
        
        # Adiciona a nova leitura de ângulo ao histórico
        angulo_atual = hub.imu.tilt()[0]
        historico_angulos.append(angulo_atual)

        # Remove leituras antigas se a janela for excedida
        if len(historico_angulos) > tamanho_janela:
            historico_angulos.pop(0)

        # Cálculo da Média Móvel Ponderada
        pesos = range(1, len(historico_angulos) + 1)  # Pesos crescentes
        angulo_medio = sum(a * p for a, p in zip(historico_angulos, pesos)) / sum(pesos)

def AnotaCor():
    global colors_note

    Send("ESTADO", Estado.COR)
    hub.display.off()

    menu_keys = colors_array
    menu_index = 0

    selected = menu_keys[menu_index]
    hub.light.on(colors_copy[selected])

    array_colors = hub.system.storage(0, read=20) 

    while True:
        result = GetButton()
        pressed = time_pressed = None
        if result is None:
            break
        else:
            pressed, time_pressed = result
            if Button.CENTER in pressed:
                if time_pressed > 500:
                    break
                else:
                    colorE = sensorE.hsv()
                    colorD = sensorD.hsv()

                    if selected == "branco":
                        print("branco :", colorE, "preto :", colorD)
                        array_colors = array_colors[:12] + hsv_to_bytes(colorD) + hsv_to_bytes(colorE)
                    else:
                        start_index = menu_index * 4
                        array_colors = array_colors[:start_index] + hsv_to_bytes(colorD) + array_colors[start_index + 4:]
                        print(selected, ":", colorD)

                    hub.system.storage(0, write=array_colors)
                    print(hub.system.storage(0, read=20))

            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

            selected = menu_keys[menu_index]
            hub.light.on(colors_copy[selected])
                
def ComparaHsv(hsv, color_name, sens=20):
    color = colors[color_name]
    hresult = abs(hsv.h - color.h) <= sens
    sresult = abs(hsv.s - color.s) <= sens
    vresult = abs(hsv.v - color.v) <= sens
    return hresult and sresult and vresult

def ChecaCores():
    global vermelho
    eColor = sensorE.hsv()
    dColor = sensorD.hsv()
    pitch = hub.imu.tilt()[0]

    if (ComparaHsv(eColor, "green") or ComparaHsv(dColor, "green")) and -5 < pitch < 5 and timer_noventa.time() == 0:
        sensorA = sensorD
        sensorB = sensorE
        lado_verde = -1
        print("verde")
        hub.speaker.beep(1000, 200)
        drive.stop()
        wait(500)
        drive.drive(60, 0)
        if ComparaHsv(eColor, "green") and ComparaHsv(dColor, "green"):
            print("verde BECO")
            VerdeVerde()
        elif ComparaHsv(eColor, "green"):
            sensorA = sensorE
            sensorB = sensorD
            lado_verde = 1
        
        drive.turn(-hub.imu.heading())
        drive.drive(60, 0)
        while True:
            # Verifica dnv se é verde verde caso tenha passado e n viu
            if ComparaHsv(sensorB.hsv(), "green"):
                print("verde verde")
                VerdeVerde()
                break
            if not ComparaHsv(sensorA.hsv(), "green"):
                if ComparaHsv(sensorA.hsv(), "branco", 13):
                    print("branco")
                    break
                elif ComparaHsv(sensorA.hsv(), "preto", 13):
                    Send("OCUPADO", 1)
                    SendBLE()
                    print("preto")
                    drive.straight(35)
                    drive.turn(-30 * lado_verde)
                    MoveAteCor(-vel_virada * lado_verde, vel_virada * lado_verde, 150, sensorA)
                    drive.turn(-45 * lado_verde, wait=False)
                    while not drive.done():
                        #if ComparaHsv(sensorA.hsv(), "branco", 7) or ComparaHsv(sensorA.hsv(), "green"):
                        if not ComparaHsv(sensorA.hsv(), "preto"):
                            break
                        wait(5)
                    #MoveAteCor(-vel_virada * lado_verde, vel_virada * lado_verde, 150, sensorA, cor="branco", tolerance=7)
                    drive.straight(15)
                    break
    
    elif ComparaHsv(eColor, "red") and ComparaHsv(dColor, "red") and -5 < pitch < 5:
        hub.speaker.beep(850, 200)
        drive.stop()
        vermelho = True
        print("vermelho")
        return True

    elif ComparaHsv(eColor, "prata", 5) and ComparaHsv(dColor, "prata", 5) and -5 < pitch < 5:
        print("prata")
        drive.stop()
        hub.speaker.beep(1000, 100)
        wait(500)
        pitch = hub.imu.tilt()[0]
        if ComparaHsv(sensorE.hsv(), "prata", 5) and ComparaHsv(sensorD.hsv(), "prata", 5):
            Send("ESTADO", Estado.RESGATE)
            return True

    return False

def VerdeVerde():
    print("beco")
    while True:
        if not ComparaHsv(sensorD.hsv(), "green"):
            if ComparaHsv(sensorD.hsv(), "branco", 13):
                print("branco")
                break
            elif ComparaHsv(sensorD.hsv(), "preto", 13):
                Send("OCUPADO", 1)
                SendBLE()
                print("preto")
                drive.straight(30)
                drive.turn(180)
                drive.straight(20)
                break

def ChecaObstaculo():
    global total_raio, margem_obs
    lado = 1
    Send("OCUPADO", 1)
    SendBLE()
    pitch = hub.imu.tilt()[0]
    distancia = ultraF.distance()
    if distancia <= 50 and -5 < pitch < 5:
        drive.stop()
        wait(250)
        if ultraF.distance() <= 50:
            drive.straight(-60)
            for x in range(1500):
                PidSeguidor(forcaBase - 200)
            ultra_preciso(40, 70)
            wait(100)
            ang_inicial = hub.imu.heading() + 90
            drive.turn(90 * lado)
            Curva(total_raio, -360 * lado, wait=False)
            while not ComparaHsv(sensorD.hsv(), "preto") and not ComparaHsv(sensorE.hsv(), "preto"):
                if ultraF.distance() < 120:
                    print("bateu no obs")
                    drive.stop()
                    Curva(-total_raio, -(ang_inicial - hub.imu.heading()) - 5)
                    drive.turn(-90 * lado)
                    ultra_preciso(45, 70)
                    drive.turn(-90 * lado)
                    MoveAteCor(120, 120, 50, sensorE, sensorD, "branco", 9)
                    drive.straight(25)
                    ang_inicial = hub.imu.heading()
                    lado = -lado
                    Curva(total_raio, -360 * lado, wait=False)
                wait(5)
            wait(100)
            print("viu preto obs")
            drive.straight(35)
            drive.turn(90*lado)
            ultra_preciso(40, -100, ultra=ultraT)
    Send("OCUPADO", 0)

def Seguidor():
    global integral, last_error, pid_erro, _KP, _KD
    sensorA = sensorD
    sensorB = sensorE
    lado_preto = 1
    corE = sensorE.hsv()
    corD = sensorD.hsv()
    atualizar_angulo_medio()

    if -17 < angulo_medio < 10:
        if ComparaHsv(corD, "preto", 12) and ComparaHsv(corE, "branco") or ComparaHsv(corE, "preto", 12) and ComparaHsv(corD, "branco"):
            Logica90(corE, corD, lado_preto, sensorA, sensorB)

    if angulo_medio <= -10:
        kp = _KP
        _KP = 6
        kd = _KD
        _KD = 9
        PidSeguidor(forcaBase-200)
        _KP = kp
        _KD = kd
    else:
        PidSeguidor(forcaBase)

def Logica90(corE, corD, lado_pretin, sensorA, sensorB):
    global integral, last_error, pid_erro, vel_virada
    lado_preto = lado_pretin
    if ComparaHsv(corE, "preto", 12):
        sensorA = sensorE
        sensorB = sensorD
        lado_preto = -1
    timer_noventa.resume()
    drive.straight(35)
    # if ComparaHsv(sensorA.hsv(), "green") or ComparaHsv(sensorB.hsv(), "green"):
    #     drive.straight(40)
    #     return
    giro = MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 190, sensorB, cor="preto")
    if not giro:
        MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorA, cor="preto")
        MoveAteCor(vel_virada * lado_preto, -vel_virada * lado_preto, 500, sensorA, cor="branco", tolerance=7)
        drive.straight(-10)
        return
    MoveAteCor(-vel_virada * lado_preto, vel_virada * lado_preto, 500, sensorB, cor="branco", tolerance=7)
    drive.turn(-5 * lado_preto)
    drive.straight(-10)

def PidSeguidor(vel):
    global integral, last_error, pid_erro
    if timer_noventa.time() > 1000:
        timer_noventa.pause()
        timer_noventa.reset()
    pid_erro = sensorD.reflection() - sensorE.reflection()
    if ComparaHsv(sensorE.hsv(), "branco") and ComparaHsv(sensorD.hsv(), "branco"):
        pid_erro = 0
    if pid_erro < 15:
        hub.imu.reset_heading(0)
    proporcional = pid_erro * _KP
    integral += pid_erro * _KI
    derivado = (pid_erro - last_error) * _KD
    correcao = proporcional + integral + derivado
    negativeForce = abs(pid_erro) * erro_vel_factor
    motorE.run((vel - negativeForce) - correcao)
    motorD.run((vel - negativeForce) + correcao)
    last_error = pid_erro

def MoveAteCor(speed_left, speed_right, distance, sensorA, sensorB = None, cor = "preto", tolerance=20):
    global preto_max, preto_min
    motorE.reset_angle(0)
    motorD.reset_angle(0)

    target_angle = distance * (360 / (3.1416 * 30.9))

    while abs(motorE.angle()) < target_angle and abs(motorD.angle()) < target_angle:
        if sensorB == None:
            if ComparaHsv(sensorA.hsv(), cor, tolerance):
                return True
        else:
            if ComparaHsv(sensorA.hsv(), cor, tolerance) or ComparaHsv(sensorB.hsv(), cor, tolerance):
                return True
        motorE.run(speed_left)
        motorD.run(speed_right)

    motorE.stop()
    motorD.stop()
    return False

def ultraReta(speed, distance, ultraDist, factor, sensorA, sensorB=None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    ultra_factor = 0
    drive.reset()
    while distance == 0 or abs(drive.distance()) < distance:
        if sensorA:
            if sensorB == None:
                if ComparaHsv(sensorA.hsv(), "preto", 18):
                    drive.stop()
                    print("preto")
                    return "Preto"
            else:
                if ComparaHsv(sensorA.hsv(), "preto", 18) or ComparaHsv(sensorB.hsv(), "preto", 18):
                    drive.stop()
                    print("preto")
                    return "Preto"
        if ultraDist:
            if ultraF.distance() <= ultraDist:
                ultra_factor += 1
                if ultra_factor > factor:
                    drive.stop()
                    drive.straight(50)
                    print("parede")
                    return "Parede"
            else:
                ultra_factor = 0

        motorE.run(speed)
        motorD.run(speed)
        wait(5)

    drive.stop()
    print("distancia")
    return "Distancia"

def Reta(distance, sens, sensorA = None, sensorB = None):
    motorE.reset_angle(0)
    motorD.reset_angle(0)
    ultra_factor = 0
    drive.reset()
    drive.settings(*reta_settings)
    drive.straight(distance if distance != 0 else 2000, wait=False)
    while not drive.done():
        if sensorA:
            if sensorB == None:
                if ComparaHsv(sensorA.hsv(), "preto", 13):
                    drive.stop()
                    drive.settings(*fast_settings)
                    return "Preto"
            else:
                if ComparaHsv(sensorA.hsv(), "preto", 13) or ComparaHsv(sensorB.hsv(), "preto", 13):
                    drive.stop()
                    drive.settings(*fast_settings)
                    return "Preto"
        # print(f"DLoad: {motorD.load()} ELoad: {motorE.load()}")
        if abs(motorD.load()) > sens or abs(motorE.load()) > sens:
            drive.stop()
            drive.settings(*fast_settings)
            return "Bateu"

        wait(5)

    drive.stop()
    drive.settings(*fast_settings)
    return "Distancia"

def angle_preciso(angulo_desejado):    
    diferenca = (angulo_desejado - hub.imu.heading() + 180) % 360 - 180
    drive.turn(diferenca)
    
def ultra_preciso(dist_desejada, velocidade=400, margem = 1, ultra=ultraF):
    while True:
        dist_atual = ultra.distance()  # Atualiza o ângulo atual
        erro = dist_desejada - dist_atual 

        if abs(erro) < margem:  # Se o erro for menor que 2 graus, parar
            break

        # Controla a velocidade do motor proporcional ao erro
        velocidade_ajustada = velocidade if erro < 0 else -velocidade
        motorE.run(velocidade_ajustada)
        motorD.run(velocidade_ajustada)
        
        wait(10)

    # Parar os motores
    motorE.stop()
    motorD.stop()
    wait(100)

def Curva(raio, angle, wait=True):
    drive.settings(*default_settings)
    drive.curve(raio, angle, wait=wait)
    drive.settings(*fast_settings)

def RetaResgate(dist = 0, speed_left = 700, speed_right=700): 
    if ultraF.distance() < 120:
        Reta(ultraF.distance() - 150, 120)
    Send("GARRA", Garra.ABERTA)
    SendBLE()
    wait(500)
    reta = Reta(dist, 140, sensorA=sensorE, sensorB=sensorD)
    print(f"reta: {reta} dist: {drive.distance()}")
    if reta == "Bateu":
        drive.straight(-15)
        if ultraF.distance() < 120:
            ultra_preciso(100, 130)
        else:
            drive.straight(-15)
    Send("GARRA", Garra.FECHADA)
    SendBLE()
    wait(950)
    return reta

def Resgate():
#Verifica se está no meio ou no canto----------------------------------------
    vel_reta = 700
    tipo_area = None

    saidaMeio = None
    saidaCanto = [0.0, 0]
    tri_verde = None
    tri_vermelho = None
    lado = 0

    dist_pra_tras = 270

    hub.imu.reset_heading(0)
    Send("GARRA", Garra.ABERTA)
    SendBLE()
    wait(500)
    drive.straight(450)
    Send("GARRA", Garra.FECHADA)
    SendBLE()
    wait(500)
    drive.straight(50)
    dist = [0.0, 0.0, 0.0]
    drive.turn(90)
    for _ in range(3):
        print(_)
        reta = RetaResgate(0)
        dist[_] = drive.distance()
        wait(100)
        if reta == "Preto":
            dist[_] -= 150
            saidaMeio = hub.imu.heading()
            drive.straight(-100)
        wait(200)
        # if _ == 0 and dist[_] > 650:
        #     tipo_area = Area.HORIZONTAL
        if _ == 1 and dist[_] > 500:
            tipo_area = Area.VERTICAL
            drive.straight(-450)
        elif _ == 2:
            retaA = dist[0]
            retaC = dist[2] - (retaA - dist_pra_tras)
            if retaA + retaC > 600 or tipo_area == Area.HORIZONTAL:
                tipo_area = Area.HORIZONTAL
                drive.straight(-450)
                break
        if not tipo_area or _ == 2 and tipo_area == Area.VERTICAL:
            drive.straight(-dist_pra_tras)
        if _ != 2:
            drive.turn(-90)

    if tipo_area == None:
        tipo_area = Area.QUADRADA

    if tipo_area == Area.HORIZONTAL:
        print("Horizontal")
    elif tipo_area == Area.VERTICAL:
        print("Vertical")
    else:
        print("Quadrado")

    if lado == 0:
        retaA = dist[0]
        retaC = dist[2] - (retaA - dist_pra_tras)
        print("retac: ", retaC)
        if abs(retaA) < 100:
            lado = 1
        elif abs(retaC) < 100:
            lado = -1
    print("lado: ", lado)

    drive.turn(-90)
    print(abs(retaA - retaC))
    if abs(retaA - retaC) > 200:
        reta = RetaResgate(0)
        if reta == "Preto":
            saidaMeio = hub.imu.heading()
        drive.straight(-drive.distance())

    if tipo_area == Area.HORIZONTAL:
        print("Horizontal")
    elif tipo_area == Area.VERTICAL:
        print("Vertical")
    elif tipo_area == Area.QUADRADA:
        print("Quadrado")

    if tipo_area == Area.QUADRADA:
        drive.turn(45 * (lado if lado != 0 else -1))
    elif tipo_area == Area.HORIZONTAL:
        drive.turn(55 * (lado if lado != 0 else -1))
    else:
        drive.turn(35 * (lado if lado != 0 else -1))


    for _ in range(3 if lado != 0 else 4):
        reta = RetaResgate(300 if tipo_area == Area.QUADRADA else 350)
        print("a")
        Reta(110, 120)
        wait(500)
        GetBLE()
        print(f"ultra: {ultraF.distance()}")
        if not Read("FCOR") == 0:
            print("viu triangulo")
            if Read("FCOR") == 1:
                tri_verde = hub.imu.heading()
            elif Read("FCOR") == 2:
                tri_vermelho = hub.imu.heading()

            if tipo_area == Area.QUADRADA:
                drive.straight(-260)
            else:
                drive.straight(-450)
        else:
            hub.speaker.beep(900, 100)
            angulo_saida = hub.imu.heading()
            if saidaCanto[1] == 0:
                print(tipo_area)
                if tipo_area != Area.QUADRADA:
                    drive.turn(55)
                else:
                    drive.turn(45)
                wait(100)
                if ultraF.distance() >= 200:
                    saidaCanto = [angulo_saida, -1]
                drive.turn(-90)
                wait(100)
                if ultraF.distance() >= 200:
                    saidaCanto = [angulo_saida, 1]
                if tipo_area != Area.QUADRADA:
                    drive.turn(45)
                else:
                    drive.turn(45) 
            if tipo_area == Area.QUADRADA:
                drive.straight(-350)
            else:
                drive.straight(-450)
        if _ < (2 if lado != 0 else 3):
            if tipo_area == Area.QUADRADA:
                drive.turn(90 * (lado if lado != 0 else -1))
            elif tipo_area == Area.HORIZONTAL:
                drive.turn((85 * (lado if lado != 0 else -1)) if _ % 2 == 0 else 95 * (lado if lado != 0 else -1))
            else:
                drive.turn((105 * (lado if lado != 0 else -1)) if _ % 2 == 0 else 75 * (lado if lado != 0 else -1))

    
    print("saida meio: ", saidaMeio)
    print("saida canto: ", saidaCanto)
    print("tri_verde: ", tri_verde, "tri_vermelho: ", tri_vermelho)
    triangulo = tri_verde if tri_verde != None else tri_vermelho
    if triangulo == None:
        triangulo = 45
    angle_preciso(triangulo - 180)

    if tipo_area == Area.QUADRADA:
        drive.straight(-200)
    else:
        drive.straight(-270)
    Reta(-300, 120)
    Send("GARRA", Garra.ABERTA)
    Send("PORTA", Porta.ABERTA)
    SendBLE()
    wait(2000)
    Send("PORTA", Porta.FECHADA)
    SendBLE()
    wait(1500)
    Send("GARRA", Garra.FECHADA)
    SendBLE()
    
    if tipo_area == Area.QUADRADA:
        drive.straight(300)
    else:
        drive.straight(420)
    
    if saidaMeio == None:
        angle_preciso(saidaCanto[0])

        reta = Reta(320, 140)
        if reta == "Bateu":
            drive.straight(-15)

        drive.turn(45 * saidaCanto[1])
        Reta(0, 120)
        drive.straight(-50)
        drive.turn(-90 * saidaCanto[1])
        drive.straight(170)
    else:
        angle_preciso(saidaMeio if saidaMeio != None else 0 + 15)
        drive.straight(450)

    Send("ESTADO", Estado.PLAY)
    SendBLE()

def Play():
    global integral, last_error, vermelho
    integral = 0
    last_error = 0
    vermelho = False
    GetStoredColors(colors, colors_array)
    Send("ESTADO", Estado.PLAY)
    SetHubColor(0, 50)
    hub.system.set_stop_button([Button.CENTER])
    timer_noventa.reset()
    timer_noventa.pause()

    EsperaHubCima()

    while True:
        GetBLE()
        if vermelho:
            drive.stop()
            break

        if Send("ESTADO") == Estado.PLAY:
            drive.settings(forcaBase)
            ChecaObstaculo()
            Send("OCUPADO", 0)
            if not ChecaCores():
                Seguidor()
            else:
                if vermelho:
                    break
        elif Send("ESTADO") == Estado.RESGATE:
            Resgate()

        SendBLE()

if __name__ == "__main__":
    print("Main")

#RETA MENOR  270
#RETA MAIOR  400