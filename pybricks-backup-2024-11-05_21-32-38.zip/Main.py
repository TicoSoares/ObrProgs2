from pybricks.parameters import Button, Icon
from pybricks.tools import wait

from ExtraTools import *

menu_options = {}
menu_keys = []

from HadesBaixo import Play, AnotaCor
menu_options = {
    "Cor": 100,
    "Play": 0,
}
menu_keys = ["Cor", "Play"]

Send("ESTADO", Estado.MAIN)
menu_index = 0

selected = menu_keys[menu_index]
BlinkHubColor(menu_options[selected])

hub.display.icon(Icon.FULL)

def SelectProgram(program):

    while CheckAnyButton():
        wait(10)

    hub.display.off()
    SetHubColor(menu_options[program], 50)
    if program == "Cor":
        AnotaCor()
    elif program == "Play":
        Play()

    hub.display.icon(Icon.FULL)
    selected = menu_keys[menu_index]
    BlinkHubColor(menu_options[selected])

    while CheckStopButton():
        wait(10)

    Send("ESTADO", Estado.MAIN)
def Start():
    global selected, menu_index, menu_keys, menu_options

    while CheckAnyButton():
        wait(10)

    while True:
        hub.system.set_stop_button([Button.LEFT, Button.CENTER])
        result = GetButton()
        pressed = time_pressed = None

        if result is None:
            if Read("ESTADO") == Estado.PLAY:
                SelectProgram("Play")
            if Read("ESTADO") == Estado.COR:
                SelectProgram("Cor")

        if result is not None:
            pressed = result[0]
            if Button.CENTER in pressed:
                SelectProgram(selected)
            elif Button.LEFT in pressed:
                menu_index = (menu_index - 1) % len(menu_keys)
            elif Button.RIGHT in pressed:
                menu_index = (menu_index + 1) % len(menu_keys)

        selected = menu_keys[menu_index]
        BlinkHubColor(menu_options[selected])
        wait(20)

if __name__ == "__main__":
    if CheckSideButton():
        Start()
    else:
        Play()