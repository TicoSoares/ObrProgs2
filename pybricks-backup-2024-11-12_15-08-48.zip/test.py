from pybricks.hubs import PrimeHub
from pybricks.pupdevices import ColorSensor, UltrasonicSensor, ForceSensor, Motor
from pybricks.parameters import Port
from pybricks.iodevices import PUPDevice
from pybricks.tools import wait
from uerrno import ENODEV

hub = PrimeHub()
motorA = Motor(Port.A)
motorA.run_angle(300,-90)
while True:
    motorA.run_angle(300, 180)
    wait(100)
    motorA.run_angle(300, -180)

# motor = None

# device_names = {
#     48: "\033[96mMotor Medio\033[0m",  # Azul claro
#     49: "\033[94mMotor Grande\033[0m",  # Azul escuro
#     61: "\033[92mSensor de Cor\033[0m",         # Verde
#     62: "\033[95mSensor Ultrassonico\033[0m",   # Roxo
#     63: "\033[91mSensor de Toque\033[0m"        # Vermelho
# }

# ports = [Port.A, Port.B, Port.C, Port.D, Port.E, Port.F]

# # Dicionário para armazenar as instâncias dos dispositivos
# devices = {}

# # Função para inicializar os dispositivos conectados às portas
# def initialize_devices():
#     for port in ports:
#         try:
#             device = PUPDevice(port)
#             id = device.info()["id"]
#             if id in [48, 49]:  # Motores
#                 devices[port] = Motor(port)
#             elif id == 61:
#                 devices[port] = ColorSensor(port)
#             elif id == 62:
#                 devices[port] = UltrasonicSensor(port)
#             elif id == 63:
#                 devices[port] = ForceSensor(port)
#         except OSError as ex:
#             if ex.args[0] == ENODEV:
#                 devices[port] = None  # Nenhum dispositivo conectado na porta
#             else:
#                 raise ex
# initialize_devices()

# while True:
#     for port in ports:
#         device = None
#         if devices.get(port) is not None:
#             device = devices[port]
#             if isinstance(device, Motor):
#                 device.run(900)
